const { buildFunction } = require("@webiny/project-utils");

module.exports = {
    commands: {
        build: buildFunction
    }
};
